package cn.smbms.service;

import java.util.List;

import cn.smbms.entity.User;

public interface UserService {

	public static final String SERVICE_NAME ="cn.smbms.service.impl.UserServiceImpl";
	
	public List<User> findUserList();
	
	/**
	 * ����idɾ���û�
	 * @param id
	 * @return
	 */
	int deleteUserById(int id);
}
