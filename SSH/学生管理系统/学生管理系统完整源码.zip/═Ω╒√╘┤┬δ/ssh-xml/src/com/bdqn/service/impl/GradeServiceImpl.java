package com.bdqn.service.impl;

import java.util.List;

import com.bdqn.dao.GradeDao;
import com.bdqn.entity.Grade;
import com.bdqn.service.GradeService;

public class GradeServiceImpl implements GradeService{
	
	
	private GradeDao gradeDao;
	public void setGradeDao(GradeDao gradeDao) {
		this.gradeDao = gradeDao;
	}


	@Override
	public List<Grade> findGradeList() throws Exception {
		// TODO Auto-generated method stub
		return gradeDao.findGradeList();
	}

}
