package com.bdqn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bdqn.dao.UserMapper;
import com.bdqn.entity.User;
import com.bdqn.service.UserService;

@Service(UserService.SERVICE_NAME)
@Transactional
public class UserServiceImpl implements UserService{
	
	@Resource
	private UserMapper userMapper;

	@Override
	public int addUser(User user) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.addUser(user);
	}

	@Override
	public List<User> findUserList() throws Exception {
		// TODO Auto-generated method stub
		return userMapper.findUserList();
	}

	@Override
	public User findUserById(int id) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.findUserById(id);
	}

	@Override
	public int updateUser(User user) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.updateUser(user);
	}

}
