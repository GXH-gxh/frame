package com.bdqn.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.bdqn.entity.User;

public interface UserAnnotationQueryRepository extends Repository<User, Integer>{

	/**
	 * 使用HQL语句完成根据姓名查询用户信息
	 * @param name
	 * @return
	 */
	@Query("from User where userName = ?1")
	List<User> findUserByHQL(String name);
	
	/** 使用SQL语句完成根据姓名查询用户信息
	 * @param name
	 * @return
	 */
	@Query(value="select * from t_user where user_name = ?1",nativeQuery=true)
	List<User> findUserBySQL(String name);
	
	/** 
	 * 命名参数查询
	 * 命名参数名称必须与方法中的参数名称一致
	 * @param name
	 * @return
	 */
	@Query(value="select * from t_user where user_name like %:name%",nativeQuery=true)
	List<User> findUserBySQLWithParam(String name);
	
	
	
	
	/** 
	 * 命名参数查询
	 * 命名参数名称必须与方法中的参数名称一致
	 * 如果想不一致，需要使用@Param()
	 * @param name
	 * @return
	 */
	@Query(value="select * from t_user where user_name like %:userName%",nativeQuery=true)
	List<User> findUserBySQLWithParam2(@Param("userName") String name);
	
	/**
	 * 修改
	 * @param username
	 * @param id
	 */
	@Modifying//标记为更新操作
	@Query("update User set userName =?1 where id=?2")
	void updateUser(String username,int id);

}
