package com.bdqn.service;

import com.bdqn.entity.User;

public interface UserService {
	
	public static final String SERVICE_NAME = "com.bdqn.service.impl.UserServiceImpl";
	
	/**
	 * 添加用户
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int addUser(User user) throws Exception;
}
