package lucene;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class IndexReaderDemo {

	public static void main(String[] args) throws IOException {
		//第一步：创建一个Directory对象，也就是索引库存放的位置。
		Directory directory = FSDirectory.open(new File("D:\\soft-install-location\\lucene\\1.teach").toPath());
		//第二步：创建一个indexReader对象，需要指定Directory对象。
		IndexReader indexReader = DirectoryReader.open(directory);
		//第三步：创建一个indexsearcher对象，需要指定IndexReader对象
		IndexSearcher indexSearcher = new IndexSearcher(indexReader);
		//第四步：创建一个TermQuery对象，指定查询的域和查询的关键词。
		//指定域的名称以及要查找的结果
		Query query = new TermQuery(new Term("name","apache"));
		//第五步：执行查询。
		TopDocs topDocs = indexSearcher.search(query, 10);
		System.out.println("查询总记录数："+topDocs.totalHits);
		//第六步：返回查询结果。遍历查询结果并输出。
		ScoreDoc [] docs =  topDocs.scoreDocs;
		for (ScoreDoc scoreDoc : docs) {
			//获取每个文档对应的id
			int docId = scoreDoc.doc;
			//获取文档对象
			Document document = indexSearcher.doc(docId);
			System.out.println("文件名："+document.get("name"));
			System.out.println("文件路径："+document.get("path"));
			System.out.println("文件大小："+document.get("size"));
			System.out.println("\n------------------- 分割线 --------------------\\n");
		}
		//第七步：关闭IndexReader对象
		indexReader.close();
	}
}
