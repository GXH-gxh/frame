package com.bdqn.action;

public class TestAction extends BaseAction{
	
	private String userName;
	private String password;
	
	
	public String test() {
		System.out.println("=============test()============");
		return SUCCESS;
	}
	
	public String login() {
		System.out.println(userName+","+password);
		return SUCCESS;
	}


	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	

}
