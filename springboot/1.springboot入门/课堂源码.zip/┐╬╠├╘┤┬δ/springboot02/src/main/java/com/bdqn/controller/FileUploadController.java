package com.bdqn.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController //(@Controller+@ResponseBody)
public class FileUploadController {

	@RequestMapping("/fileUpload")
	public Map<String, Object> fileUpload(MultipartFile filename){
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			System.out.println("文件名称："+filename.getOriginalFilename()); 
			filename.transferTo(new File("D:\\"+filename.getOriginalFilename()));
			map.put("msg", "文件上传成功！");
		}  catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			map.put("msg", "文件上传失败！");
		}
		return map;
	}
}
