package com.bdqn.dao;

import org.springframework.data.repository.CrudRepository;

import com.bdqn.entity.User;

/**
 * 支持简单的增删改查操作
 * @author KazuGin
 *
 */
public interface UserCrudRepository extends CrudRepository<User, Integer>{

}
