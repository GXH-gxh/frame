package com.bdqn.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

	@RequestMapping("/test")
	public String test(Model model) {
		System.out.println("============进入控制器============");
		model.addAttribute("msg", "Thymeleaf");
		model.addAttribute("key", new Date());
		model.addAttribute("sex", "男");
		model.addAttribute("id", 2);
		return "test";
	}
}
