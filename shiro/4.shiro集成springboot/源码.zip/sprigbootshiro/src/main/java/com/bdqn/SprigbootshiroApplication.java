package com.bdqn;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages="com.bdqn.dao")
public class SprigbootshiroApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprigbootshiroApplication.class, args);
	}

}
