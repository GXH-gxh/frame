package com.bdqn.service;

import java.util.Set;

import com.bdqn.entity.User;

public interface UserService {
	/**
	 * 根据用户名查询用户信息的方法
	 * @param userName
	 * @return
	 */
	User getUserByName(String userName);
	
	/**
	 * 根据用户名获取该用户拥有的角色
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	Set<String> getRoles(String userName) throws Exception;
	
	/**
	 * 根据用户名获取该用户拥有的权限
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	Set<String> getPermissions(String userName) throws Exception;
}
