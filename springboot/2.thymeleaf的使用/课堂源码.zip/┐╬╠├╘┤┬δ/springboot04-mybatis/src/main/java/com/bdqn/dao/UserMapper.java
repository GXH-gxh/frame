package com.bdqn.dao;

import com.bdqn.entity.User;

public interface UserMapper {

	/**
	 * 添加用户
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int addUser(User user) throws Exception;
}
