package com.bdqn.action;

import com.bdqn.entity.User;
import com.opensymphony.xwork2.ModelDriven;

public class UserAction extends BaseAction implements ModelDriven<User>{

	//ģ��������װ
	private User user = new User();
	@Override
	public User getModel() {
		// TODO Auto-generated method stub
		return user;
	}
	
	/**
	 * ��¼�ķ���
	 * @return
	 */
	public String login() {
		if(user.getUsername().equals("admin") && user.getPassword().equals("admin")) {
			session.setAttribute("loginUser", user);
			return "login_success";
		}
		return LOGIN;
	}
	
	public String add() {
		System.out.println("==========add()===========");
		return "add";
	}
	
	public String update() {
		System.out.println("==========update()===========");
		return "update";
	}

}
