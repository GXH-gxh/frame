package com.bdqn.realm;

import javax.annotation.Resource;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import com.bdqn.entity.User;
import com.bdqn.service.UserService;

public class UserRealm extends AuthorizingRealm{
	
	@Resource
	private UserService userService;

	/**
	 * 为当前登录的用户授权
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		// TODO Auto-generated method stub
		//1.获取当前登录的用户信息
		String userName = (String) principals.getPrimaryPrincipal();
		//2.创建授权验证对象
		SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
		try {
			//3.授予角色
			authorizationInfo.setRoles(userService.getRoles(userName));
			//4.授予权限
			authorizationInfo.setStringPermissions(userService.getPermissions(userName));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//5.返回授权信息
		return authorizationInfo;
	}

	/**
	 * 为当前登录用户进行身份验证
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		// TODO Auto-generated method stub
		//1.获取用户名
		String userName =  (String) token.getPrincipal();
		//2.调用根据用户名查询用户信息的方法
		User user = userService.getUserByName(userName);
		//3.对象不为空，表示用户存在
		if(user!=null) {
			//4.进行身份验证
			AuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user.getUserName(),user.getPassword(),"xxx");
			return authenticationInfo;
		}
		//返回null，表示验证失败
		return null;
	}

}
