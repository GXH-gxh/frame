package com.bdqn;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.bdqn.dao.UserAnnotationQueryRepository;
import com.bdqn.dao.UserCrudRepository;
import com.bdqn.dao.UserDao;
import com.bdqn.dao.UserRepository;
import com.bdqn.dao.UserRepositoryPagingAndSorting;
import com.bdqn.entity.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Springboot07JpaApplicationTests {
	
	@Resource
	private UserDao userDao;
	
	@Resource
	private UserRepository userRepository;
	
	@Resource
	private UserAnnotationQueryRepository queryRepostory;
	
	@Resource
	private UserCrudRepository userCrudRepository;
	
	@Resource
	private UserRepositoryPagingAndSorting userRepositoryPagingAndSorting;
	@Test
	public void addUser() {
		User user = new User();
		user.setAddress("广州市海珠区");
		user.setAge(20);
		user.setUserName("张三");
		
		userDao.save(user);
	}
	
	@Test
	public void testFindByUserName() {
		List<User> list = userRepository.findByUserName("张三");
		for (User user : list) {
			System.err.println(user);
		}
	}
	
	@Test
	public void testFindByUserNameAndAge() {
		List<User> list = userRepository.findByUserNameAndAge("张三", 20);
		for (User user : list) {
			System.err.println(user);
		}
	}
	
	@Test
	public void testFindByUserNameLike() {
		List<User> list = userRepository.findByUserNameLike("张%");
		for (User user : list) {
			System.err.println(user);
		}
	}
	
	@Test
	public void testFindUserByHQL() {
		List<User> list = queryRepostory.findUserByHQL("张三");
		for (User user : list) {
			System.err.println(user);
		}
	}
	@Test
	public void testFindUserBySQL() {
		List<User> list = queryRepostory.findUserBySQL("张三");
		for (User user : list) {
			System.err.println(user);
		}
	}
	
	@Test
	public void testFindUserBySQLWithParam() {
		//List<User> list = queryRepostory.findUserBySQLWithParam("李");
		List<User> list = queryRepostory.findUserBySQLWithParam2("张");
		for (User user : list) {
			System.err.println(user);
		}
	}
	
	@Test
	@Transactional//与@Test一起使用时,事务会自动回滚
	@Rollback(false)//取消自动回归
	public void testUpdateUserByQuery() {
		queryRepostory.updateUser("王五", 2);
	}
	
	
	/*****************测试CrudRepository接口********************/
	@Test
	public void testCrudSaveUser() {
		User user = new User();
		user.setAddress("广州市海珠区");
		user.setAge(20);
		user.setUserName("张浩");
		userCrudRepository.save(user);
	}
	
	@Test
	public void testCrudUpdateUser() {
		User user = new User();
		user.setAddress("广州市荔湾区");
		user.setAge(20);
		user.setUserName("张浩");
		user.setId(4);//指定主键，save()方法则执行修改操作
		userCrudRepository.save(user);
	}
	
	@Test
	public void testFindUserById() {
		Optional<User> user =  userCrudRepository.findById(4);
		System.err.println(user);
	}
	
	@Test
	public void testFindUserList() {
		List<User> list = (List<User>) userCrudRepository.findAll();
		for (User user : list) {
			System.out.println(user);
		}
	}
	
	@Test
	public void testDeleteUser() {
		userCrudRepository.deleteById(4);
	}
	
	@Test
	public void testSortUser() {
		//设置排序（升序、降序，排序属性）
		Order order = new Order(Direction.DESC,"id");
		//创建排序对象
		Sort sort = new Sort(order);
		List<User> list = (List<User>) userRepositoryPagingAndSorting.findAll(sort );
		for (User user : list) {
			System.out.println(user);
		}
	}
	
	@Test
	public void testPageList() {
		//Pageable:封装了分页的参数，当前页，每页显示的条数。注意：当前页是从0开始。
		//PageRequest(page,size) page:当前页。size:每页显示的条数
		Pageable pageable = new PageRequest(1, 2);
		//分页查询
		Page<User> page = this.userRepositoryPagingAndSorting.findAll(pageable);
		System.out.println("总数量："+page.getTotalElements());
		System.out.println("总页数："+page.getTotalPages());
		//获取用户列表
		List<User> list = page.getContent();
		for (User user : list) {
			System.out.println(user);
		}
	}
	
	
	
}
