package cn.smbms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/page")
public class PageController {

	/**
	 * ��ת��̨��ҳ
	 * @return
	 */
	@RequestMapping("/home")
	public String home() {
		return "main";
	}
	
	/**
	 * �û�����ҳ��
	 * @return
	 */
	@RequestMapping(value="/userManager")
	public String userManager() {
		return "userManager";
	}
}
