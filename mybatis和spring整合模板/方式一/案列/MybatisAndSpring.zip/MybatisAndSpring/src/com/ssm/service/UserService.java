package com.ssm.service;

import java.util.List;

import com.ssm.entity.User;

public interface UserService {
	
	public List<User> findAll();
}
