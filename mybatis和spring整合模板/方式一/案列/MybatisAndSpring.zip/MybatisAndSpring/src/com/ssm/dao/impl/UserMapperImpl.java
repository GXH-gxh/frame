package com.ssm.dao.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

import com.ssm.dao.UserMapper;
import com.ssm.entity.User;

public class UserMapperImpl implements UserMapper{
	
	private SqlSessionTemplate SqlSessionTemplate;
	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		SqlSessionTemplate = sqlSessionTemplate;
	}


	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return SqlSessionTemplate.selectList("com.ssm.dao.UserMapper.findAll");
	}

}
