package com.bdqn;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//加载mybatis映射文件
@MapperScan("com.bdqn.dao")
public class Springboot04MybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot04MybatisApplication.class, args);
	}

}
