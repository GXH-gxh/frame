package com.ssm.dao.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.ssm.dao.UserMapper;
import com.ssm.entity.User;

public class UserMapperImpl extends SqlSessionDaoSupport implements UserMapper{

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return this.getSqlSession().selectList("com.ssm.dao.UserMapper.findAll");
	}

}
