package cn.smbms.dao;

import java.util.List;
import java.util.Map;

import cn.smbms.entity.User;

public interface UserMapper {

	/**
	 * �����û������ѯ�û���Ϣ
	 * @param userCode
	 * @return
	 * @throws Exception
	 */
	User findUserByUserCode(String userCode) throws Exception;
	
	/**
	 * ͳ��������
	 * @param map
	 * @return
	 * @throws Exception
	 */
	Integer getTotalCount(Map<String, Object> map) throws Exception;
	
	/**
	 * ��ѯ�û��б�
	 * @param map
	 * @return
	 * @throws Exception
	 */
	List<User> findUserList(Map<String, Object> map) throws Exception;
	
	/**
	 * �����û�
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int addUser(User user) throws Exception;
	
	/**
	 * ����id��ѯ�û���Ϣ
	 * @param id
	 * @return
	 * @throws Exception
	 */
	User findUserById(Integer id) throws Exception;
	
	/**
	 * �޸��û�
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int updateUser(User user) throws Exception;
	
	/**
	 * ����ɾ��
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	int deleteUser(Integer [] userId) throws Exception;
}
