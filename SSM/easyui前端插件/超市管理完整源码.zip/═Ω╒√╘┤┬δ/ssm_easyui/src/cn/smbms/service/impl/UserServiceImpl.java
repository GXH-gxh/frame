package cn.smbms.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.smbms.dao.UserMapper;
import cn.smbms.entity.User;
import cn.smbms.service.UserService;
import cn.smbms.utils.PasswordUtil;

@Service(UserService.SERVICE_NAME)
public class UserServiceImpl implements UserService{
	
	
	@Resource
	private UserMapper userMapper;

	@Override
	public User login(String userCode, String password) throws Exception {
		// TODO Auto-generated method stub
		//���ø����û������ѯ�û���Ϣ�ķ���
		User user =  userMapper.findUserByUserCode(userCode);
		//����Ϊ�գ���ʾ���û��Ǵ��ڵ�
		if(user!=null) {
			//�Ծ�������м��ܴ���
			String newPassword = PasswordUtil.md5(password, userCode);
			//�Ƚ�����
			if(user.getUserPassword().equals(newPassword)) {
				//��¼�ɹ�
				return user;
			}
		}
		//��¼ʧ��
		return null;
	}

	@Override
	public Integer getTotalCount(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getTotalCount(map);
	}

	@Override
	public List<User> findUserList(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.findUserList(map);
	}

	@Override
	public int addUser(User user) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.addUser(user);
	}

	@Override
	public User findUserById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.findUserById(id);
	}

	@Override
	public int updateUser(User user) throws Exception {
		// TODO Auto-generated method stub
		user.setUserPassword(PasswordUtil.md5(user.getUserPassword(), user.getUserCode()));
		return userMapper.updateUser(user);
	}

	@Override
	public User findUserByUserCode(String userCode) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.findUserByUserCode(userCode);
	}

	@Override
	public int deleteUser(Integer[] userId) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.deleteUser(userId);
	}

}
