package lucene;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.junit.Test;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class AnalazerDemo {
	@Test
	public void testTokenStream() throws Exception{
		//1.创建一个Analyzer对象，StandardAnalyzer对象
		//Analyzer analyzer = new StandardAnalyzer();
		//Analyzer analyzer = new SmartChineseAnalyzer();
		Analyzer analyzer = new IKAnalyzer();
		//2.使用分析器对象的tokenStream方法获得一个TokenStream对象
		//TokenStream tokenStream = analyzer.tokenStream("", "The Spring Framework provides a comprehensive programming and configuration model");
		TokenStream tokenStream = analyzer.tokenStream("", "习近平主席，我爱我的祖国，我和我的祖国");
		//3.向TokenStream对象中设置一个引用
		CharTermAttribute attribute = tokenStream.addAttribute(CharTermAttribute.class);
		//4.调用TokenStream对象的rest方法。如果不调用抛异常
		tokenStream.reset();
		//5.循环遍历TokenStream对象
		while(tokenStream.incrementToken()) {
			System.out.println(attribute.toString());
		}
		//6.关闭TokenStream对象
		tokenStream.close();
	}

}
