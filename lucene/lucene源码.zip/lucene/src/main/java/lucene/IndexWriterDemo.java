package lucene;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.LongPoint;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.Test;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class IndexWriterDemo {

	@Test
	public void testCreateIndex() throws IOException {
		//1.创建Directory对象，并指定索引保存的位置
		Directory directory = FSDirectory.open(new File("D:\\soft-install-location\\lucene\\1.teach").toPath());
		//2.基于Directory对象创建IndexWriter对象
		//IndexWriter indexWriter = new IndexWriter(directory, new IndexWriterConfig());
		//使用第三方中文分词器分词
		IndexWriter indexWriter = new IndexWriter(directory, new IndexWriterConfig(new IKAnalyzer()));
		//3.读取磁盘上的文件，对应每个文件创建一个文档对象
		File dir = new File("E:\\教学资料\\教案笔记\\Y2\\11.lucene\\searchsource");//原始文档的位置
		//获取文件列表
		File [] files = dir.listFiles();
		//循环文件数组
		for (File file : files) {
			//获取文件相关信息
			String fileName = file.getName();//文件名称
			String filePath = file.getPath();//文件路径
			String fileContent  = FileUtils.readFileToString(file, "utf-8");//文件内容
			long fileSize = FileUtils.sizeOf(file);//文件大小
			//创建域对象
			//参数1：域名称（列名），参数2：域的内容（列的值），参数3：是否存储到索引库中
			Field fieldName =  new TextField("name", fileName, Field.Store.YES);
			//Field fieldPath =  new TextField("path", filePath, Field.Store.NO);
			Field fieldPath = new StoredField("path", filePath);
			Field fieldContent =  new TextField("content", fileContent, Field.Store.YES);
			//Field fieldSize =  new TextField("size", fileSize+"", Field.Store.NO);
			Field fieldSize =  new LongPoint("size", fileSize);
			//Field fieldSizeValue =  new StoredField("size", fileSize);
			//创建文档对象
			Document document = new Document();
			//4.向文档对象中添加域
			document.add(fieldName);
			document.add(fieldPath);
			document.add(fieldContent);
			document.add(fieldSize);
			//document.add(fieldSizeValue);
			//5.把文档对象添加到索引库
			indexWriter.addDocument(document);
		}
		//6.关闭IndexWriter对象
		indexWriter.close();
	}
}
