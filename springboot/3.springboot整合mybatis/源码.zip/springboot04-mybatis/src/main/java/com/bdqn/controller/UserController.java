package com.bdqn.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bdqn.entity.User;
import com.bdqn.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Resource
	private UserService userService;
	
	/**
	 * 页面跳转
	 * @param page
	 * @return
	 */
	@RequestMapping("/{page}")//index
	public String page(@PathVariable String page) {
		return page;//index
	}
	

	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String add(User user) {
		try {
			int count = userService.addUser(user);
			if(count>0) {//成功
				return "redirect:userlist";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//失败
		return "add";
	}
	
	@RequestMapping("/userlist")
	public String userlist(Model model) {
		try {
			List<User> userList = userService.findUserList();
			//将数据放到模型中
			model.addAttribute("userList", userList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "userlist";
	}
	
	@RequestMapping("/toupdate/{id}")
	public String toUpdate(@PathVariable int id,Model model) {
		try {
			User user =userService.findUserById(id);
			model.addAttribute("user", user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "update";
	}
	
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String update(User user) {
		try {
			int count = userService.updateUser(user);
			if(count>0) {//成功
				return "redirect:userlist";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//失败
		return "redirect:toupdate?id="+user.getId();
	}
}
