package com.bdqn.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;

@WebServlet("/login")
public class LoginServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("================  执行 login doGet()方法  =================");
		req.getRequestDispatcher("login.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("================  执行 login doGet()方法  =================");
		req.setCharacterEncoding("utf-8");
		//获取用户名密码
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");
		//获取当前的Subject对象
		Subject subject = SecurityUtils.getSubject();
		//创建令牌
		UsernamePasswordToken token = new UsernamePasswordToken(userName,password);
		try {
			//登录，传入令牌
			subject.login(token);
			//重定向到成功页面
			resp.sendRedirect("success.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			req.setAttribute("errorInfo", "用户名密码错误");
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		}
	}

	
}
