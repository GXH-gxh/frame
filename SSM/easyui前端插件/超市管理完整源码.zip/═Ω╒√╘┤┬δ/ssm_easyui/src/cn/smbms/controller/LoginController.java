package cn.smbms.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.smbms.entity.User;
import cn.smbms.service.UserService;
import cn.smbms.utils.Constants;

@Controller
@RequestMapping("/user")
public class LoginController {
	
	@Resource
	private UserService userService;

	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(User user,HttpSession session) {
		try {
			//���õ�¼�ķ���
			User loginUser = userService.login(user.getUserCode(), user.getUserPassword());
			//�������Ϊ�գ���ʾ��¼�ɹ�
			if(loginUser!=null) {
				session.setAttribute(Constants.CURRENT_USER, loginUser);
				//��ת����̨��ҳ
				return "redirect:/page/home";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//��¼ʧ��
		return "redirect:/login.jsp";
	}
}
