package com.bdqn.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

//全局异常处理类
//@ControllerAdvice
public class GlobalException {
	//空指针异常
		@ExceptionHandler(value= {NullPointerException.class})
		public ModelAndView nullExeception(Exception e) {
			ModelAndView view = new ModelAndView();
			//保存异常信息
			view.addObject("exception", e.toString());
			//设置逻辑视图名
			view.setViewName("error1");
			return view;
		}
		
		//算术异常
		@ExceptionHandler(value= {ArithmeticException.class})
		public ModelAndView arithmeticExeception(Exception e) {
			ModelAndView view = new ModelAndView();
			//保存异常信息
			view.addObject("exception", e.toString());
			//设置逻辑视图名
			view.setViewName("error2");
			return view;
		}
		
}
