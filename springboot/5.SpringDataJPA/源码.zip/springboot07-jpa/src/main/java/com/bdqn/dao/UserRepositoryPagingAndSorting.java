package com.bdqn.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.bdqn.entity.User;

/**
 * 支持分页及排序
 * @author KazuGin
 *
 */
public interface UserRepositoryPagingAndSorting extends PagingAndSortingRepository<User, Integer>{

}
