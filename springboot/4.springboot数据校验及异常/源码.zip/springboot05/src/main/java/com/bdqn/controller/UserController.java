package com.bdqn.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bdqn.entity.User;

@Controller
public class UserController {
	/**
	 * 去到添加用户页面
	 * @return
	 */
	@RequestMapping("/addUser")
	public String addUser(@ModelAttribute("user") User user) {
		return "add";
	}
	/**
	 * 保存用户
	 * @param user
	 * @return
	 */
	@RequestMapping("/saveUser")
	public String saveUser(@ModelAttribute("user") @Valid User user,BindingResult result) {
		//如果验证有误，回到添加页面
		if(result.hasErrors()) {
			return "add";
		}
		System.out.println(user);
		return "ok";
	}
}
