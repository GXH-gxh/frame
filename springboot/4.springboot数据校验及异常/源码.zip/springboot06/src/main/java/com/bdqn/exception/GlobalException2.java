package com.bdqn.exception;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

//全局异常处理类
@Configuration
public class GlobalException2 {
	@Bean
	public SimpleMappingExceptionResolver getSimpleMappingExceptionResolver() {
		SimpleMappingExceptionResolver resolver = new SimpleMappingExceptionResolver();
		Properties mappings = new Properties();
		//设置对应异常映射的页面
		//参数1：异常类型  参数2：关联映射页面
		mappings.put("java.lang.ArithmeticException", "error1");
		mappings.put("java.lang.NullPointerException", "error2");
		//设置异常与映射的关联信息
		resolver.setExceptionMappings(mappings);
		return resolver;
	}

		
}
