package com.bdqn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot07JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot07JpaApplication.class, args);
	}

}
