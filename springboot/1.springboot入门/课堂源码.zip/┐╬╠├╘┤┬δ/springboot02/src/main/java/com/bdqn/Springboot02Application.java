package com.bdqn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.bdqn.filter.TestFilter;
import com.bdqn.listener.TestListener;
import com.bdqn.servlet.IndexServlet;

@SpringBootApplication
//通过注解扫描加载servlet组件
//@ServletComponentScan
public class Springboot02Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboot02Application.class, args);
	}

	/*
	@Bean
	public ServletRegistrationBean getServletRegistrationBean() {
		//创建实例
		ServletRegistrationBean bean = new ServletRegistrationBean(new IndexServlet());
		//注册路径
		bean.addUrlMappings("/index");
		//返回
		return bean;
	}
	*/
	
	/*
	@Bean
	public FilterRegistrationBean getFilterRegistrationBean() {
		FilterRegistrationBean bean = new FilterRegistrationBean(new TestFilter());
		//过滤单个
		bean.addUrlPatterns("/index");
		//过滤多个
		//bean.addUrlPatterns(new String[] {".action",".do"});
		//返回
		return bean;
	}
	*/
	
	
	//监听
	@Bean
	public ServletListenerRegistrationBean getsServletListenerRegistrationBean() {
		ServletListenerRegistrationBean bean  = new ServletListenerRegistrationBean(new TestListener());
		return bean;
	}
	
}
