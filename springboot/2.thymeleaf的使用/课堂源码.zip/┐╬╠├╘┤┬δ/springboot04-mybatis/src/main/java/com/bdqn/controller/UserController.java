package com.bdqn.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bdqn.entity.User;
import com.bdqn.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Resource
	private UserService userService;
	
	/**
	 * 页面跳转
	 * @param page
	 * @return
	 */
	@RequestMapping("/{page}")//index
	public String page(@PathVariable String page) {
		return page;//index
	}
	

	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String add(User user) {
		try {
			int count = userService.addUser(user);
			if(count>0) {//成功
				return "list";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//失败
		return "add";
	}
	
}
