package com.bdqn.interceptor;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

public class SystemInterceptor extends MethodFilterInterceptor{

	@Override
	protected String doIntercept(ActionInvocation invocation) throws Exception {
		// TODO Auto-generated method stub
		//��ȡSession
		HttpSession session = ServletActionContext.getRequest().getSession();
		//sessionΪ�գ���ʾû�е�¼
		if(session.getAttribute("loginUser")==null) {
			//�ص���¼ҳ��
			return Action.LOGIN;
		}
		//����
		return invocation.invoke();
	}

}
