package com.bdqn.dao;

import java.util.List;

import com.bdqn.entity.User;

public interface UserMapper {

	/**
	 * 添加用户
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int addUser(User user) throws Exception;
	
	/**
	 * 查询用列表
	 * @return
	 * @throws Exception
	 */
	List<User> findUserList() throws Exception;
	
	/**
	 * 根据用户编号查询用户信息
	 * @param id
	 * @return
	 * @throws Exception
	 */
	User findUserById(int id) throws Exception;
	
	/**
	 * 修改
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int updateUser(User user) throws Exception;
}
