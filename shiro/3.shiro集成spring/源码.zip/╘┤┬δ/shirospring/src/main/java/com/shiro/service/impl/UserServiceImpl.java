package com.shiro.service.impl;

import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.shiro.dao.UserMapper;
import com.shiro.entity.User;
import com.shiro.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Resource
	private UserMapper userMapper;
	
	public User findUserByName(String userName) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.findUserByName(userName);
	}

	public Set<String> getRoles(String userName) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getRoles(userName);
	}

	public Set<String> getPermissions(String userName) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getPermissions(userName);
	}

}
