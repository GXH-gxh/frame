package lucene;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.wltea.analyzer.lucene.IKAnalyzer;

public class IndexManager {

	private IndexWriter indexWriter;

	@Before
	public void init() throws IOException {
		// 1.创建Directory对象，并指定索引保存的位置
		Directory directory = FSDirectory.open(new File("D:\\soft-install-location\\lucene\\1.teach").toPath());
		// 2.基于Directory对象创建IndexWriter对象
		// 使用第三方中文分词器分词
		indexWriter = new IndexWriter(directory, new IndexWriterConfig(new IKAnalyzer()));
	}
	
	@Test
	public void testAddDocument() throws IOException {
		//创建文档对象
		Document document = new Document();
		document.add(new TextField("name", "新添加的文档",Store.YES));
		document.add(new TextField("content", "这是星期三新添加的文档",Store.YES));
		//将文档写入到索引库
		indexWriter.addDocument(document);
	}
	
	@After
	public void destory() throws IOException {
		//关闭indexWriter
		indexWriter.close();
	}
}
