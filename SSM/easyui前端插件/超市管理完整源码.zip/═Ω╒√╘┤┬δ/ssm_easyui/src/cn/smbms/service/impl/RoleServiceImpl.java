package cn.smbms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.smbms.dao.RoleMapper;
import cn.smbms.entity.Role;
import cn.smbms.service.RoleService;

@Service(RoleService.SERVICE_NAME)
public class RoleServiceImpl implements RoleService{
	
	@Resource
	private RoleMapper roleMapper;

	@Override
	public List<Role> findRoleList() throws Exception {
		// TODO Auto-generated method stub
		return roleMapper.findRoleList();
	}

}
