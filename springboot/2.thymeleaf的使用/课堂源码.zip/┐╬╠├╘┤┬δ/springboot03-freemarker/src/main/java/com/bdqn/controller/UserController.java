package com.bdqn.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bdqn.entity.User;

@Controller
public class UserController {
	
	@RequestMapping("/userList")
	public String list(Model model) {
		List<User> list = new ArrayList<User>();
		list.add(new User(1,"张三",20));
		list.add(new User(2,"李四",21));
		list.add(new User(3,"王五",22));
		list.add(new User(4,"赵六",23));
		//将数据放到model模型中
		model.addAttribute("userList", list);
		//设置逻辑视图名（页面名称）
		return "userList";
	}

}
