package com.bdqn.service.impl;

import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.bdqn.dao.UserMapper;
import com.bdqn.entity.User;
import com.bdqn.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Resource
	private UserMapper userMapper;

	@Override
	public User getUserByName(String userName) {
		// TODO Auto-generated method stub
		return userMapper.getUserByName(userName);
	}
	
	public Set<String> getRoles(String userName) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getRoles(userName);
	}

	public Set<String> getPermissions(String userName) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.getPermissions(userName);
	}

}
