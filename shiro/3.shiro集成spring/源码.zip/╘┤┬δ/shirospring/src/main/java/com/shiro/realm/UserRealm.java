package com.shiro.realm;

import javax.annotation.Resource;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

import com.shiro.entity.User;
import com.shiro.service.UserService;

/**
 * 用户自定义Realm
 * @author KazuGin
 *
 */
public class UserRealm extends AuthorizingRealm{
	
	@Resource
	private UserService userService;

	/**
	 * 授权（为当前登录的用户授予权限及角色）
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		// TODO Auto-generated method stub
		//1.获取当前登录的用户信息
		String userName = (String) principals.getPrimaryPrincipal();
		//2.创建授权验证对象
		SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
		try {
			//3.授予角色
			authorizationInfo.setRoles(userService.getRoles(userName));
			//4.授予权限
			authorizationInfo.setStringPermissions(userService.getPermissions(userName));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//5.返回授权信息
		return authorizationInfo;
	}

	/**
	 * 身份验证（为当前登录的用户进行身份验证）
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		// TODO Auto-generated method stub
		//从AuthenticationToken获取当前用户信息
	    String userName = (String) token.getPrincipal();
		try {
			//调用根据用户名称查询用户信息的方法
			User user = userService.findUserByName(userName);
			//对象不为空，则表示当前用户是存在的
			if(user!=null) {
				//验证用户名及密码
				AuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user.getUserName(), user.getPassword(), "xxx");
				//返回验证信息
				return authenticationInfo;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//验证失败
		return null;
	}

}
