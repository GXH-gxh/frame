package com.bdqn.dao;

import java.util.List;

import com.bdqn.entity.Grade;

public interface GradeDao {

	/**
	 * ��ѯ�꼶�б�
	 * @return
	 * @throws Exception
	 */
	List<Grade> findGradeList() throws Exception;
}
