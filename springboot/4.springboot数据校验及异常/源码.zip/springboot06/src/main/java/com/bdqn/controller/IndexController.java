package com.bdqn.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class IndexController {
	
	@RequestMapping("/show")
	public String show() {
		String str = null;
		str.length();
		return "index";
	}
	
	@RequestMapping("/show2")
	public String show2() {
		System.out.println(1/0);
		return "index";
	}
	
	//空指针异常
	/*
	@ExceptionHandler(value= {NullPointerException.class})
	public ModelAndView nullExeception(Exception e) {
		ModelAndView view = new ModelAndView();
		//保存异常信息
		view.addObject("exception", e.toString());
		//设置逻辑视图名
		view.setViewName("error1");
		return view;
	}
	
	//算术异常
	@ExceptionHandler(value= {ArithmeticException.class})
	public ModelAndView arithmeticExeception(Exception e) {
		ModelAndView view = new ModelAndView();
		//保存异常信息
		view.addObject("exception", e.toString());
		//设置逻辑视图名
		view.setViewName("error2");
		return view;
	}
	*/

}
