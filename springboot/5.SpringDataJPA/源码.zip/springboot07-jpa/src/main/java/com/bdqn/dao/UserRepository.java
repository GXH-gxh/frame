package com.bdqn.dao;

import java.util.List;

import org.springframework.data.repository.Repository;

import com.bdqn.entity.User;

/**
 * 方法名称命名查询
 * @author KazuGin
 *
 */
public interface UserRepository extends Repository<User, Integer>{

	//注意：必须遵循骆驼命名法[findBy(关键字)+实体类属性名称(首字母要大写)+查询条件(首字母大写)]
	
	/**
	 * 根据名称查询用户信息
	 * @param name
	 * @return
	 */
	List<User> findByUserName(String name);
	
	/**
	 * 根据名称及年龄查询用户信息
	 * @param name
	 * @param age
	 * @return
	 */
	List<User> findByUserNameAndAge(String name,int age);
	
	/**
	 * 根据用户名模糊查询
	 * @param name
	 * @return
	 */
	List<User> findByUserNameLike(String name);
}
