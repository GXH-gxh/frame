package com.bdqn.service;

import java.util.List;

import com.bdqn.entity.Grade;

public interface GradeService {
	/**
	 * ��ѯ�꼶�б�
	 * @return
	 * @throws Exception
	 */
	List<Grade> findGradeList() throws Exception;
}
