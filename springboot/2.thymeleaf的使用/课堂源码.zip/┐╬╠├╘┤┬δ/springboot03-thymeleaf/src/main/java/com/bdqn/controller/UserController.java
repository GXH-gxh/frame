package com.bdqn.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bdqn.entity.User;

@Controller
public class UserController {
	
	@RequestMapping("/userList")
	public String list(Model model) {
		List<User> list = new ArrayList<User>();
		list.add(new User(1,"张三",20));
		list.add(new User(2,"李四",21));
		list.add(new User(3,"王五",22));
		list.add(new User(4,"赵六",23));
		//将数据放到model模型中
		model.addAttribute("userList", list);
		//设置逻辑视图名（页面名称）
		return "userList";
	}
	
	@RequestMapping("/userList2")
	public String list2(Model model) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("u1", new User(1,"张三1",20));
		map.put("u2", new User(2,"张三2",20));
		map.put("u3", new User(3,"张三3",20));
		map.put("u4", new User(4,"张三4",20));
		//将数据放到model模型中
		model.addAttribute("userList", map);
		//设置逻辑视图名（页面名称）
		return "userList2";
	}
	
	@RequestMapping("/attr")
	public String attr(HttpServletRequest request) {
		request.setAttribute("req", "request作用域");
		request.getSession().setAttribute("ses", "session作用域");
		request.getSession().getServletContext().setAttribute("app", "全局作用域");
		return "attr";
	}
	
	@RequestMapping("/demo")
	public String demo(String id,String age) {
		System.out.println("================id:"+id);
		System.out.println("================age:"+age);
		return "attr";
	}
	
	@RequestMapping("/path/{id}")
	public String path(@PathVariable String id) {
		return "attr";
	}

}
