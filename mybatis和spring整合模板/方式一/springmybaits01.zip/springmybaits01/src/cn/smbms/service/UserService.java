package cn.smbms.service;

import java.util.List;

import cn.smbms.entity.User;

public interface UserService {

	public List<User> findUserList();
}
