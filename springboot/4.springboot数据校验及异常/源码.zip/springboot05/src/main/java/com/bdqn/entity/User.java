package com.bdqn.entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

public class User {
	@NotBlank(message="用户名不能为空")
	private String name;
	@NotEmpty(message="密码不能为空")
	private String password;
	@Min(message="年龄最小为16岁",value=16)
	@Max(message="年龄最大为60岁",value=60)
	private Integer age;
	private String email;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", password=" + password + ", age=" + age + ", email=" + email + "]";
	}
}
