package cn.smbms.dao;

import java.util.List;

import cn.smbms.entity.Role;

public interface RoleMapper {

	/**
	 * ��ѯ���н�ɫ��Ϣ
	 * @return
	 * @throws Exception
	 */
	List<Role> findRoleList() throws Exception;
}
