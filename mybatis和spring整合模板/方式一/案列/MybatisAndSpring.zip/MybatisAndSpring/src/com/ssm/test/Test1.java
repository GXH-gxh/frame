package com.ssm.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.entity.User;
import com.ssm.service.UserService;

public class Test1 {
	@Test
	public void test01() {
		ApplicationContext ac = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserService service =  (UserService) ac.getBean("userService");
		List<User> list = service.findAll();
		
		for (User user : list) {
			System.out.println("��ţ�-"+user.getId()+"������-"+user.getUserName()+"���룺-"+user.getUserCode());
		}
	}
}
