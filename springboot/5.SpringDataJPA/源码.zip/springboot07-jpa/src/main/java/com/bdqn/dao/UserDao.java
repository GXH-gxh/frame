package com.bdqn.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bdqn.entity.User;

/**
 * 用户接口
 * 参数1：具体操作的实体类
 * 参数2：该实体类主键的数据类型
 * @author KazuGin
 *
 */
public interface UserDao extends JpaRepository<User, Integer>{

}
