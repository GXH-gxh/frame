package cn.smbms.service;

import java.util.List;

import cn.smbms.entity.Role;

public interface RoleService {

	public static final String SERVICE_NAME = "cn.smbms.service.impl.RoleServiceImpl";
	
	/**
	 * ��ѯ���н�ɫ��Ϣ
	 * @return
	 * @throws Exception
	 */
	List<Role> findRoleList() throws Exception;
}
