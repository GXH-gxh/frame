package com.bdqn.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import com.bdqn.dao.GradeDao;
import com.bdqn.entity.Grade;

public class GradeDaoImpl extends HibernateDaoSupport implements GradeDao {

	@Override
	public List<Grade> findGradeList() throws Exception {
		// TODO Auto-generated method stub
		return (List<Grade>) this.getHibernateTemplate().find("from Grade");
	}

}
