package cn.smbms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.smbms.dao.UserMapper;
import cn.smbms.entity.User;
import cn.smbms.service.UserService;

@Service(UserService.SERVICE_NAME)
public class UserServiceImpl implements UserService{
	
	//ע��userMapper
	@Resource
	private UserMapper userMapper;


	@Override
	public List<User> findUserList() {
		// TODO Auto-generated method stub
		return userMapper.findUserList();
	}


	@Override
	public int deleteUserById(int id) {
		// TODO Auto-generated method stub
		return userMapper.deleteUserById(id);
	}

}
